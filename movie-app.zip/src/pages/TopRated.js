import MovieList from "../components/movieList/MovieList"

const TopRated = () => {
  return (
    <>
    <MovieList/>
    
    </>
  )
}

export default TopRated