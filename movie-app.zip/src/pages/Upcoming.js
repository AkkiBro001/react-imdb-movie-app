import MovieList from "../components/movieList/MovieList"

const Upcoming = () => {
  return (
    <>
    <MovieList/>
    
    </>
  )
}

export default Upcoming