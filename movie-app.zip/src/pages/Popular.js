import MovieList from "../components/movieList/MovieList";


const Popular = () => {
    return (
        <MovieList/>
    )
}

export default Popular;